
package com.example.jarvisunlock

import android.Manifest
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.RecognitionListener

class MainActivity : AppCompatActivity(), RecognitionListener {
    private lateinit var model: Model
    private lateinit var recognizer: Recognizer
    private lateinit var speechService: SpeechService
    private lateinit var animationView: LottieAnimationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        setContentView(R.layout.activity_main)

        animationView = findViewById(R.id.jarvis_animation)

        Thread {
            model = Model("model")
            recognizer = Recognizer(model, 16000.0f)
            speechService = SpeechService(recognizer, 16000.0f)
            speechService.startListening(this)
        }.start()
    }

    override fun onPartialResult(hypothesis: String?) {
        if (hypothesis?.contains("hey jarvis unlock", true) == true) {
            runOnUiThread {
                animationView.playAnimation()
                MediaPlayer.create(this, R.raw.welcome_back).start()
                Handler().postDelayed({
                    try {
                        Runtime.getRuntime().exec(arrayOf("su", "-c", "input keyevent 82"))
                        Toast.makeText(this, "Phone Unlocked!", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Root permission needed", Toast.LENGTH_LONG).show()
                    }
                }, 2000)
            }
        }
    }

    override fun onResult(result: String?) {}
    override fun onFinalResult(result: String?) {}
    override fun onError(e: Exception?) {}
    override fun onTimeout() {}
}
